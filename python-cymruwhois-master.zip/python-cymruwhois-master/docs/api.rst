API
---

.. autoclass:: cymruwhois.Client
   :members: lookup,lookupmany,lookupmany_dict
   :undoc-members:

